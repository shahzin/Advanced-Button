//
//  UIAdvancedButtonTests.m
//  UIAdvancedButtonTests
//
//  Created by Shahzin KS on 28/08/13.
//  Copyright (c) 2013 sksarts. All rights reserved.
//

#import "UIAdvancedButtonTests.h"

@implementation UIAdvancedButtonTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in UIAdvancedButtonTests");
}

@end
