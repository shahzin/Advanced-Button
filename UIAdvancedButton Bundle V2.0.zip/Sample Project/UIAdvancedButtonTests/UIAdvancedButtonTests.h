//
//  UIAdvancedButtonTests.h
//  UIAdvancedButtonTests
//
//  Created by Shahzin KS on 28/08/13.
//  Copyright (c) 2013 sksarts. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface UIAdvancedButtonTests : SenTestCase

@end
