//
//  ABThirdViewController.h
//  UIAdvancedButton
//
//  Created by Shahzin KS on 30/08/13.
//  Copyright (c) 2013 sksarts. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIAdvancedButton.h"

@interface ABThirdViewController : UIViewController
- (IBAction)didTappedCloseButton:(id)sender;

@end
