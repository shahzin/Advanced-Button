//
//  ABAppDelegate.h
//  UIAdvancedButton
//
//  Created by Shahzin KS on 28/08/13.
//  Copyright (c) 2013 sksarts. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ABAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
