//
//  main.m
//  UIAdvancedButton
//
//  Created by Shahzin KS on 28/08/13.
//  Copyright (c) 2013 sksarts. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ABAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ABAppDelegate class]));
    }
}
